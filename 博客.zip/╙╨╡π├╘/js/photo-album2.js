$(document).ready(function(){
    $('img').hide(300).show(1000);

    //控制图片的淡出 
    $('img').click(function(){
        $('img').animate({width:"200px"});
    })

    $('img').dblclick(function(){
        $('img').animate({width:"300px"});
    })

    $('img').animate({left:"100px"});

    $('.photo_name-01').click(function(){
        $('.ph1').fadeToggle("slow");
    })

    $('.photo_name-02').click(function(){
        $('.ph2').fadeToggle("slow");
    })

    $('.photo_name-03').click(function(){
        $('.ph3').fadeToggle("slow");
    })

    $('.photo_name-04').click(function(){
        $('.ph4').fadeToggle("slow");
    })

    $('.photo_name-05').click(function(){
        $('.ph5').fadeToggle("slow");
    })

    $('.photo_name-06').click(function(){
        $('.ph6').fadeToggle("slow");
    })

    $('.photo_name-07').click(function(){
        $('.ph7').fadeToggle("slow");
    })

    $('.photo_name-08').click(function(){
        $('.ph8').fadeToggle("slow");
    })

    $('.photo_name-09').click(function(){
        $('.ph9').fadeToggle("slow");
    })

    $('.photo_name-10').click(function(){
        $('.ph10').fadeToggle("slow");
    })

    $('.photo_name-11').click(function(){
        $('.ph11').fadeToggle("slow");
    })

    $('.photo_name-12').click(function(){
        $('.ph12').fadeToggle("slow");
    })
    
    $('.photo_name-13').click(function(){
        $('.ph13').fadeToggle("slow");
    })

    $('.photo_name-14').click(function(){
        $('.ph14').fadeToggle("slow");
    })

    $('.photo_name-15').click(function(){
        $('.ph15').fadeToggle("slow");
    })

    $('.photo_name-16').click(function(){
        $('.ph16').fadeToggle("slow");
    })


    // 
   
})

    $(document).ready(function(){
        $('#btn').click(function(){
            $('.ph1').fadeToggle();
            $('.ph2').fadeToggle();
            $('.ph3').fadeToggle();
            // $('.ph4').fadeToggle();
            $('.ph4').fadeToggle();
            $('.ph5').fadeToggle();
            $('.ph6').fadeToggle();
            $('.ph7').fadeToggle();
            $('.ph8').fadeToggle();
            $('.ph9').fadeToggle();
            $('.ph10').fadeToggle();
            $('.ph11').fadeToggle();
            $('.ph12').fadeToggle();
            $('.ph13').fadeToggle();
            $('.ph14').fadeToggle();
            $('.ph15').fadeToggle();
            $('.ph16').fadeToggle();
        })
    })